Need For Speed Most Wanted 2012 Realistic Plugin v4.02
============================================================================
Disclaimer
============================================================================
If this Application manipulates your game or computer in a harmful way, 
I claim no responsibility.  I am not associated with the game developers in 
any way and I am distributing this Application free of charge, use at your 
own risk!

============================================================================
Installation
============================================================================
CHOOSE ONLY ONE METHOD

PROXY DLL METHOD: Extract version.dll to your game installation directory.

INJECT DLL METHOD: Extract Remote Injection anywhere. Run Plugin Injector.

============================================================================
Uninstallation
============================================================================

PROXY DLL METHOD: Delete version.dll from your game installation directory.

INJECT DLL METHOD: Delete Remote Injection Folder

============================================================================
Notes
============================================================================
* Should work with any version (FutureScan)

* For Logitech wheels I found that I needed to invert the spring effect.

* Linearity only functions when Raw steering input is enabled.

* For 900 degree steering you will need to add some linearity, I found that 
  15 to 20 is a good linear value and force-feedback set to 1.5x.

* The mouse is used for changing the camera angles; The mouse-wheel controls
  the camera Roll, X and Y control Yaw and Pitch

* SAVE/LOAD Views:  The hotkeys for this are hard coded to the
  numbers across the top of the keyboard (not the Function keys!)
  To load a preset, hold Ctrl and press any number 0-9. 
  To save a preset, hold ALT and press any number 0-9.

* There are 3 camera modes.
  1. Original Modified
  2. Locked to car
  3. Locked to car + Orbit

* There are also 3 camera modes while in Free-Look.
  1. normal free look
  2. cinematic with manual FOV
  3. cinematic with auto FOV

============================================================================
Camera Control HotKeys
============================================================================
Numpad * = Toggle Camera Control On
Numpad / = Toggle Camera Control Off
Numpad 9 = Toggle Free-Look
Numpad 3 = Toggle TrackIR (must be enabled in config first)
Numpad 7 = Toggle HUD

Numpad 1 = Next Preset

Numpad 0 = Toggle Mouse
Numpad . = Change Camera  Mode (Changes to Cinematic Mode if Free-Look enabled)
Numpad + = Toggle Glass Texture

U = Move Up
T = Move Down
G = Move Left
J = Move Right
Y = Move Forward
H = Move Backward
k = Reset View

] = Increase FOV
[ = Decrease FOV

SHIFT = Move Faster

============================================================================
Usage
============================================================================
1) Start game then press Numpad * to enable new cameras
2) Change to 3rd Person view then press Numpad 1 to cycle new cameras or 
   create your own.
3) Press Numpad / to disable new cameras and return to default
4) Steering and force-feedback options are always enabled.

============================================================================
Version History
============================================================================
- What's new in v4.02 on 9/8/2013?
 *Fixed 'Use Raw Input' feature with v1.5 patch

- What's new in v4.00 on 5/3/2013?
 *Fixed support for v1.5 patch
 *Added some crash catching routines
 *Support files (tir.dll, views.cam, etc..)  have been moved and are automatically extracted to 
  [MY DOCUMENTS]\Criterion Games\Need For Speed(TM) Most Wanted\Plugin\ 
  on first run.  

  If you want to use your old cam file you can copy it to this folder.
  If you have old version, you can safely remove these old files from the game directory.

 *Added cinematic camera (use change mode key while in Free-Look)
  There is three modes in Free-Look now.
  1. normal free look
  2. cinematic with manual FOV
  3. cinematic with auto FOV
  


- What's new in v3.04 on 1/3/2013?
 *Fixed problem with 'Enable Raw Input' checkbox (was always on before)

- What's new in v3.03 on 1/2/2013?
 *Fixed problem with HUD toggle not working

- What's new in v3.02 on 12/15/2012?
 *Fixed and tested TrackIR

- What's new in v3.01 on 12/13/2012?
 *Fixed a spring multiplier bug

- What's new in v3.0 on 12/13/2012?
 *Changed name from Camera Control to Realistic Plugin
 *Added Dialog window on launch
 *Added advanced force-feedback options (spring multiplier)
 *Added advanced steering options (raw input, linearity)
 *Added ability to disable crash cams
 *Added ability to auto enable camera control
 *Added ability to toggle glass texture (effects occlusion is still occurring)
 *Last preset used is now remembered
 *Fixed more bugs with cutscenes, etc.

- What's new in v2.0 on 11/22/2012?
 *Added toggle HUD HotKey (Num 7)
 *Camera is restored during accident or cutscene
 *Re-ordered controls
 *Fixed a bug that saved presets each frame

- What's new in v1.02 on 11/8/2012?
 *Possible Windows 8 crash fix
 *Fixed random beeping sound?

- What's new in v1.01 on 11/7/2012?
 *Fixed FOV increasing after crash
 
- What's new in v1.0 on 11/6/2012?
 *First version

============================================================================
Known Bugs
============================================================================
* may need to make minor adjustments to cam for each car

============================================================================
Contact - Bug Reports
============================================================================
ToCA EDIT: http://www.tocaedit.com
You like this? I like donations!
Made by Racer_S